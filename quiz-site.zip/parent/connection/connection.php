<?php
$conn = mysqli_connect('localhost', 'root', '', 'quiz_site', 3306) or die("Connection failed: " . mysqli_connect_error());

// $conn = mysqli_connect('sql300.infinityfree.com', 'if0_36820165', '6nLvLYmSiJ0e1Ee', 'if0_36820165_quiz_site') or die("Connection failed: " . mysqli_connect_error());


// $conn = mysqli_connect('localhost', 'u797177118_admin_quiz', 'QuizSite123', 'u797177118_quiz_site') or die("Connection failed: " . mysqli_connect_error());