# Quiz-Site
This is a quiz site for students for different classes. Admin will control everything
